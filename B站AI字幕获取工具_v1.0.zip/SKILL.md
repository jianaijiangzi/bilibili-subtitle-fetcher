---
name: bilibili-subtitle-fetcher
title: B站AI字幕获取工具
description: 获取任意B站视频的AI字幕文本，让AI能像真人一样理解视频内容后生成评论
version: 1.0.0
author: KANA
tags:
  - bilibili
  - subtitle
  - video
  - content-understanding
---

# B站AI字幕获取工具

## 📖 功能介绍

这个技能让AI能够获取B站视频的AI字幕文本，理解视频内容后生成真实的评论——就像真人看完视频一样。

**核心能力：**
- ✅ 支持任意B站视频（只要有AI字幕）
- ✅ 纯文本获取，token消耗极低（约3000-4000/视频）
- ✅ 成本极低：Claude Sonnet 4约¥0.004/次，DeepSeek V3约¥0.0004/次
- ✅ 比Whisper音频转录节省100-250倍成本

## 🚀 使用流程

### 1. 准备Cookie（一次性配置）

**获取方式：**
1. 浏览器打开 https://www.bilibili.com 并登录
2. 按 `F12` 打开开发者工具
3. 切换到 `Network`（网络）标签
4. 刷新页面，随便点一个请求
5. 在右侧找到 `Request Headers` → `Cookie`
6. 完整复制整段Cookie值

**关键字段（必须包含）：**
- `SESSDATA=xxxxx`
- `bili_jct=xxxxx`
- `DedeUserID=xxxxx`

### 2. 找到视频的BV号和CID

**BV号：** 视频URL里的标识符
- 例如 `https://www.bilibili.com/video/BV1uyJt61EuT/` 
- BV号就是 `BV1uyJt61EuT`

**CID：** 视频的内部ID（需要查询）
- 方法1：打开视频页面，F12开发者工具 → Network → 筛选 `player` → 找到包含 `cid=` 的请求
- 方法2：访问 `https://api.bilibili.com/x/web-interface/view?bvid={BV号}` → 查看返回的 `data.cid`

### 3. 获取字幕

```bash
# 基础用法
python get_subtitle.py <BV号> <CID> "你的Cookie"

# 指定输出文件
python get_subtitle.py BV1uyJt61EuT 42951708446 "your_cookie" -o subtitle.txt
```

**示例：**
```bash
python get_subtitle.py BV1uyJt61EuT 42951708446 "buvid3=461E3B60...; SESSDATA=934ff8b9..."
```

### 4. AI理解并生成评论

字幕获取成功后，你可以：
1. 将字幕文本发给AI
2. AI理解视频内容
3. 生成符合视频主题的真实评论

## 📋 使用场景

- **视频理解**：让AI快速掌握长视频内容
- **评论生成**：基于内容生成真实、有深度的评论
- **内容分析**：分析视频主题、情感、关键信息
- **批量处理**：自动化处理多个视频的字幕获取

## ⚠️ 注意事项

1. **Cookie安全**：
   - Cookie包含登录凭证，请妥善保管
   - 不要分享给他人
   - 定期更新（Cookie会过期）

2. **字幕可用性**：
   - 只支持有AI字幕的视频
   - 部分UP主可能关闭AI字幕功能
   - 需要登录态才能获取AI字幕

3. **使用限制**：
   - 遵守B站使用条款
   - 合理控制请求频率
   - 仅用于个人学习研究

## 🔧 技术细节

**API端点：**
```
https://api.bilibili.com/x/player/v2?bvid={BV号}&cid={CID}
```

**依赖：**
- Python 3.7+
- requests库

**成本对比：**
| 方案 | Token消耗 | 成本（Claude Sonnet 4） | 成本（DeepSeek V3） |
|------|-----------|------------------------|---------------------|
| AI字幕文本 | 3000-4000 | ¥0.004 | ¥0.0004 |
| Whisper转录 | 300000-1000000 | ¥0.40-1.33 | ¥0.04-0.13 |
| **节省倍数** | **100-250倍** | **100-333倍** | **100-333倍** |

## 📦 文件结构

```
skill_package/
├── get_subtitle.py      # 主脚本
├── requirements.txt     # 依赖列表
└── SKILL.md            # 本文档
```

## 🤝 贡献

欢迎提交Issue和PR改进这个技能！

---

**作者：** KANA  
**版本：** 1.0.0  
**许可：** MIT License
